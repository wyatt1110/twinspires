# 🏇 TwinSpires VPS Scraper

**Complete VPS deployment package for TwinSpires odds scraping**

## 📋 **Package Contents**
- `twinspires-scraper.js` - Main scraper (Railway-compatible)
- `scheduler.js` - VPS scheduler (every 2 minutes, 16:00-02:00 UK)
- `package.json` - Dependencies (puppeteer, supabase, cron)
- `env-example.txt` - Environment variables template
- `install.bat` - Windows auto-installer
- `VPS_SETUP_INSTRUCTIONS.md` - Complete setup guide

## ⚡ **Quick Start**
1. Extract this package to your VPS
2. Run `install.bat` (Windows) or `npm install`
3. Edit `.env` with your Supabase key
4. Start: `npm start`

## 🎯 **Why VPS?**
Railway datacenter IPs are blocked by Akamai. VPS residential IPs work perfectly!

## 📊 **Schedule**
- **Every 2 minutes** during UK racing hours (16:00-02:00)
- **Same database** as Railway system
- **Automatic timezone** handling

Ready to solve the Akamai blocking issue! 🚀
